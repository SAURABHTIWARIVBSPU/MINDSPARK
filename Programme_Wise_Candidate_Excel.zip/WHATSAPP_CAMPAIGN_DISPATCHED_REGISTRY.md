# WhatsApp Campaign Roster & Master Registry — Mind Spark 2026

> **CAMPAIGN MODE:** **FULL COHORT DISPATCH (ALL CANDIDATES)**  
> **Directive:** Full programme-wise campaign broadcast to all registered candidates (both previous and new candidates).  
> **Audit Date:** October 29, 2026  
> **Directory:** `c:\Users\Saurabh Tiwari\Desktop\MINDSPARK\Programme_Wise_Candidate_Excel`  
> **Total Registered Candidates:** **5,752 Students** (100% Accounted For)  
> **Unique Registration Numbers:** **5,752** (Zero Missed / Zero Duplicates)  
> **Valid Indian Mobile Numbers:** **5,728 (99.6%)**  
> **Manual Review Numbers (Landline/Zero):** **24**  

---

## 1. Master Campaign Summary

All **5,752 registered candidates** have been audited and organized into programme-wise workbooks ready for bulk WhatsApp broadcasting.

- **Primary Consolidated Master:** `00_COMPLETE_ALL_STUDENTS_MASTER_ROSTER.xlsx` (5,752 candidates + Summary Sheet)
- **Desktop Deliverable:** `C:\Users\Saurabh Tiwari\Desktop\MINDSPARK_2026_MASTER_WHATSAPP_CAMPAIGN_ALL_STUDENTS.xlsx`
- **Format:** Column A is strictly formatted as `number` (Numeric `91XXXXXXXXXX`, no `+` sign) for automated messaging blast software.

---

## 2. Programme-Wise File Breakdown & Candidate Count

| S.No | Excel Workbook Name | Programme / Event Name | Total Candidates | Column A Header | WhatsApp Community Group Link |
|:---:|:---|:---|:---:|:---:|:---|
| 1 | `00_COMPLETE_ALL_STUDENTS_MASTER_ROSTER.xlsx` | **ALL PROGRAMMES (CONSOLIDATED MASTER)** | **5,752** | `number` | Master Multi-Tab |
| 2 | `UNIQUE_AND_CREATIVE_HANDMADE_FANCY_DRESS.xlsx` | Unique & Creative Handmade Fancy Dress | 34 | `number` | [Join Play Group](https://chat.whatsapp.com/IRuKPAsQwsD3JOKvfoRlNe?s=cl&p=a&mlu=4&ilr=4) |
| 3 | `COLOUR_BY_NUMBER.xlsx` | Colour by Number | 200 | `number` | [Join Nursery Group](https://chat.whatsapp.com/LCkLkIPQjxoLYq83H1PL7B?s=cl&p=a&mlu=4&ilr=4) |
| 4 | `JOIN_THE_DOTS_AND_COLOUR.xlsx` | Join the Dots & Colour | 237 | `number` | [Join LKG Group](https://chat.whatsapp.com/CfTovkUjPoh1mtKJHKTzQw?s=cl&p=a&mlu=4&ilr=4) |
| 5 | `COMPLETE_THE_PICTURE_AND_COLOUR.xlsx` | Complete the Picture & Colour | 207 | `number` | [Join UKG Group](https://chat.whatsapp.com/HK4oXdNxng7Kilg5GIkAdh?s=cl&p=a&mlu=4&ilr=4) |
| 6 | `CLAY_CHAMPS.xlsx` | Clay Champs | 234 | `number` | [Join Class 1 Group](https://chat.whatsapp.com/Civ78EDwE9w3tx3QHTfF36?s=cl&p=a&mlu=4&ilr=4) |
| 7 | `DRESS_TO_IMPRESS.xlsx` | Dress to Impress | 71 | `number` | [Join Class 1 Group](https://chat.whatsapp.com/BC3BkmIFFGM2NHR6sKJeAq?s=cl&p=a&mlu=4&ilr=4) |
| 8 | `PAINT_YOUR_IMAGINATION.xlsx` | Paint Your Imagination | 454 | `number` | [Join Class 2-3 Group](https://chat.whatsapp.com/LN0NdN4Ov5Z0CenxbXhc2B?s=cl&p=a&mlu=4&ilr=4) |
| 9 | `WRITING_STARS.xlsx` | Writing Stars | 283 | `number` | [Join Class 2-3 Group](https://chat.whatsapp.com/EZdzL8T1ADm51STsu7uv6F?s=cl&p=a&mlu=4&ilr=4) |
| 10 | `BATTLE_OF_BRAINS.xlsx` | Battle of Brains | 360 | `number` | [Join Class 4-5 Group](https://chat.whatsapp.com/LQ4cJOtKOu2GyZp1QLh1ul?s=cl&p=a&mlu=4&ilr=4) |
| 11 | `POSTER_ARTIST.xlsx` | Poster Artist (incl. Junior Artist) | 416 | `number` | [Join Class 4-5 Group](https://chat.whatsapp.com/IXFH8stCsxQFBOn4RRCziG?s=cl&p=a&mlu=4&ilr=4) |
| 12 | `FIRELESS_COOKING.xlsx` | Fireless Cooking | 661 | `number` | [Join Class 6-8 Group](https://chat.whatsapp.com/CoSFm1OKCzI9dQvNPgoqr0?s=cl&p=a&mlu=4&ilr=4) |
| 13 | `JUNIOR_SCIENTIST.xlsx` | Junior Scientist (HOLD Program) | 413 | `number` | [Join Class 6-8 Group](https://chat.whatsapp.com/DtdXSmSL9xw9iclQ8Bt3IS?s=cl&p=a&mlu=4&ilr=4) |
| 14 | `YOUNG_INNOVATORS.xlsx` | Young Innovators | 165 | `number` | [Join Class 9-10 Group](https://chat.whatsapp.com/LVZkMALJ7t13QS1OQeWRAp?s=cl&p=a&mlu=4&ilr=4) |
| 15 | `ONLINE_QUIZ_CLASS_9_10.xlsx` | Online Quiz (Class 9-10) | 541 | `number` | [Join Class 9-10 Group](https://chat.whatsapp.com/GVPQlFZgMgqBns2WlQGcNe) |
| 16 | `WRITING_QUEST.xlsx` | Writing Quest | 146 | `number` | [Join Class 11-12 Group](https://chat.whatsapp.com/BKaf16sFinG6uj6JzfK5MI?s=cl&p=a&mlu=4&ilr=4) |
| 17 | `ONLINE_QUIZ_CLASS_11_12.xlsx` | Online Quiz (Class 11-12) | 535 | `number` | [Join Class 11-12 Group](https://chat.whatsapp.com/HChYAjAXd2q9i9xnXbZwme) |
| 18 | `ONLINE_QUIZ_GRADUATION.xlsx` | Online Quiz (Graduation) | 662 | `number` | [Join College Group](https://chat.whatsapp.com/FnBeq6O9TIyIGvbJiK6quw) |
| 19 | `ESSAY_WRITING.xlsx` | Essay Writing | 129 | `number` | [Join College Group](https://chat.whatsapp.com/KoiQ7KE6j11HlstZw68WJ3?s=cl&p=a&mlu=4&ilr=4) |
| 20 | `ONLINE_QUIZ.xlsx` | All Online Quiz (Consolidated Multi-Tab) | 1,738 | `number` | All Groups |
| 21 | `MISSING_EVENT.xlsx` | Unassigned / Review Required | 4 | `number` | Support Group |

**Total Across Individual Standalone Files (18 Events + Missing Event):**  
$34 + 200 + 237 + 207 + 234 + 71 + 454 + 283 + 360 + 416 + 661 + 413 + 165 + 541 + 146 + 535 + 662 + 129 + 4 = \mathbf{5,752}$  
**Audit Balance:** $\mathbf{5,752} - \mathbf{5,752} = \mathbf{0}$ (Zero Mismatch).

---

## 3. Standardized Column Schema (Matching CLAY_CHAMPS.xlsx)

Every workbook adheres to the following 17-column standard:

1. **`number` (Column A):** Integer formatted as `91XXXXXXXXXX` (no `+` sign) for direct WhatsApp software ingestion.
2. **`Candidate Name` (Column B):** Uppercase, trimmed.
3. **`Registration Number` (Column C):** Clean registration number (e.g. `MS261101847`).
4. **`Father's Name` (Column D):** Uppercase, trimmed.
5. **`Class / Course` (Column E):** Normalized class grade (e.g. `Class 1`, `Class 10`, `Graduation`).
6. **`School / College Name` (Column F):** Uppercase, trimmed.
7. **`Programme / Event Name` (Column G):** Canonical competition title.
8. **`Group Name` (Column H):** Official competition group.
9. **`Date of Birth` (Column I):** Strictly formatted as `DD-MM-YYYY`.
10. **`Candidate S.No` (Column J):** Sequential row number.
11. **`Group WhatsApp Link` (Column K):** Direct invite link for the candidate's competition group.
12. **`Exam Venue & Room` (Column L):** Venue location and room details.
13. **`Reporting & Exam Timing` (Column M):** Authoritative reporting and exam start/end times.
14. **`Mobile Status` (Column N):** `VALID_INDIAN_MOBILE` or `MANUAL_REVIEW_REQUIRED`.
15. **`WhatsApp Eligibility` (Column O):** `ELIGIBLE` or `REVIEW_REQUIRED`.
16. **`Duplicate / Shared Flag` (Column P):** `UNIQUE`, `SHARED_PHONE_SIBLING`, or `MULTI_EVENT`.
17. **`Review Notes` (Column Q):** Helpful contextual annotations for staff.
